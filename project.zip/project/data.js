const images = [{
  'id': 'YdAqiUkUoWA',
  'url': 'img/cats-1.jpg',
  'description': 'pink petaled flower',
}, {
  'id': 'hX_hf2lPpUU',
  'url': 'img/cats-2.jpg',
  'description': 'green leaf',
}, {
  'id': 'w1JE5duY62M',
  'url': 'img/cats-3.jpg',
  'description': 'red and white petaled flower close-up photography',
}, {
  'id': '3tYZjGSBwbk',
  'url': 'img/cats-4.jpg',
  'description': 'white daisy in bloom during daytime',
}, {
  'id': 'NoXUQ54pDac',
  'url': 'img/cats-5.jpg',
  'description': 'white-and-pink flowers',
}, {
  'id': 'OZhYgZh0bAg',
  'url': 'img/cats-6.jpg',
  'description': 'white and purple flower petals',
}, {
  'id': 'YdAqiUkUoWA1',
  'url': 'img/cats-1.jpg',
  'description': 'pink petaled flower',
}, {
  'id': 'hX_hf2lPpUU1',
  'url': 'img/cats-2.jpg',
  'description': 'green leaf',
}, {
  'id': 'w1JE5duY62M1',
  'url': 'img/cats-3.jpg',
  'description': 'red and white petaled flower close-up photography',
}, {
  'id': '3tYZjGSBwbk1',
  'url': 'img/cats-4.jpg',
  'description': 'white daisy in bloom during daytime',
}, {
  'id': 'NoXUQ54pDac1',
  'url': 'img/cats-5.jpg',
  'description': 'white-and-pink flowers',
}, {
  'id': 'OZhYgZh0bAg1',
  'url': 'img/cats-6.jpg',
  'description': 'white and purple flower petals',
}];

// списки выделенных и отгаданных карточек для отладки
const visibleItems = ['hX_hf2lPpUU', '3tYZjGSBwbk'];
const finishedItems = ['YdAqiUkUoWA', 'YdAqiUkUoWA1', 'w1JE5duY62M', 'w1JE5duY62M1'];
